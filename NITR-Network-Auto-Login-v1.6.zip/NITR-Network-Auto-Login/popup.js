document.addEventListener('DOMContentLoaded', () => {
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const togglePassword = document.getElementById('togglePassword');
  const saveButton = document.getElementById('saveBtn');
  const clearButton = document.getElementById('clearBtn');
  const triggerButton = document.getElementById('triggerBtn');
  const statusBox = document.getElementById('status-box');
  const netStatus = document.getElementById('net-status');

  // 1. Network status, as last detected by the background check
  const STATUS_STYLES = {
    online:     ["🟢 Logged in / Connected", "#e6f4ea", "#137333"],
    logged_out: ["🟠 Logged out, logging in…", "#fef7e0", "#b06000"],
    offline:    ["🔴 No network", "#fce8e6", "#c5221f"]
  };
  const fmt = (t) => t ? new Date(t).toLocaleTimeString() : "never";

  function renderStatus() {
    chrome.storage.local.get(['netStatus', 'lastCheckAt', 'lastLoginAt'], (d) => {
      const [text, bg, fg] = STATUS_STYLES[d.netStatus] || ["Checking network...", "#eee", "#555"];
      netStatus.textContent = text;
      netStatus.style.backgroundColor = bg;
      netStatus.style.color = fg;
      netStatus.title = `Last check: ${fmt(d.lastCheckAt)} · Last auto-login: ${fmt(d.lastLoginAt)}`;
    });
  }
  renderStatus();
  chrome.runtime.sendMessage({ action: "check_now" }, () => renderStatus());

  // 2. Load saved credentials
  chrome.storage.local.get(['campusUser', 'campusPass'], (data) => {
    if (data.campusUser) usernameInput.value = data.campusUser;
    if (data.campusPass) passwordInput.value = data.campusPass;
  });

  // 3. Password visibility toggle
  togglePassword.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    togglePassword.textContent = type === 'password' ? '👁️' : '🔒';
  });

  // 4. Save credentials action
  saveButton.addEventListener('click', () => {
    const user = usernameInput.value.trim();
    const pass = passwordInput.value.trim();

    chrome.storage.local.set({ campusUser: user, campusPass: pass }, () => {
      statusBox.textContent = "✓ Credentials Saved!";
      statusBox.style.display = "block";
      setTimeout(() => { statusBox.style.display = "none"; }, 2000);
    });
  });

  // 5. Clear credentials action
  clearButton.addEventListener('click', () => {
    chrome.storage.local.remove(['campusUser', 'campusPass'], () => {
      usernameInput.value = "";
      passwordInput.value = "";
      statusBox.textContent = "🗑️ Data Cleared!";
      statusBox.style.display = "block";
      setTimeout(() => { statusBox.style.display = "none"; }, 2000);
    });
  });

  // 6. Manual Trigger Login Action
  triggerButton.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const showMsg = (msg) => {
      statusBox.textContent = msg;
      statusBox.style.display = "block";
      setTimeout(() => { statusBox.style.display = "none"; }, 2000);
    };
    if (tab) {
      chrome.tabs.sendMessage(tab.id, { action: "manual_trigger" }, () => {
        void chrome.runtime.lastError; // no content script on this tab is fine
      });
    }
    // Also make sure the portal is open (reuses an existing portal tab).
    chrome.runtime.sendMessage({ action: "open_portal" }, () => {
      showMsg("⚡ Opening portal & logging in...");
    });
  });
});
