// Background service worker: detects when the campus session has expired
// and opens the portal login page in a background tab. content.js then fills
// in the saved credentials and clicks Login, exactly as before.

const PORTAL_URL = "https://login.nitrkl.ac.in/PortalMain";
const PORTAL_MATCH = "*://login.nitrkl.ac.in/*";
// Plain-HTTP endpoint that returns an empty 204 when the internet is reachable.
// A captive portal intercepts it and redirects to the login page instead.
const PROBE_URL = "http://connectivitycheck.gstatic.com/generate_204";

const CHECK_ALARM = "nitr-status-check";
const CHECK_PERIOD_MIN = 1;          // how often to check (minutes)
const BASE_COOLDOWN_MS = 60 * 1000;  // wait at least 1 min between opening attempts
const MAX_COOLDOWN_MS = 15 * 60 * 1000; // backoff cap: 15 min

let checking = false;

// ---------- connectivity detection ----------

async function fetchWithTimeout(url, options = {}, ms = 8000) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), ms);
    try {
        return await fetch(url, { cache: "no-store", ...options, signal: ctrl.signal });
    } finally {
        clearTimeout(timer);
    }
}

async function portalReachable() {
    try {
        await fetchWithTimeout(PORTAL_URL, { redirect: "follow" });
        return true;
    } catch (e) {
        return false;
    }
}

// Returns "online", "logged_out", or "offline".
async function detectStatus() {
    if (!navigator.onLine) return "offline";

    try {
        const res = await fetchWithTimeout(PROBE_URL, { redirect: "manual" });
        if (res.status === 204) return "online";
        // A redirect (opaqueredirect) or any other page means something
        // intercepted the request, i.e. the captive portal.
        return "logged_out";
    } catch (e) {
        // The probe failed outright. If the campus portal still answers, we are
        // on the campus network but blocked, so logged out. If the portal does
        // not answer either, we are offline or off campus: do nothing.
        return (await portalReachable()) ? "logged_out" : "offline";
    }
}

// ---------- opening the portal ----------

async function findPortalTab() {
    const tabs = await chrome.tabs.query({ url: PORTAL_MATCH });
    return tabs[0] || null;
}

async function openPortal() {
    const existing = await findPortalTab();
    if (existing) {
        // Reuse the tab we already have; reload so the login form is shown again.
        await chrome.tabs.reload(existing.id);
        return;
    }
    try {
        await chrome.tabs.create({ url: PORTAL_URL, active: false });
    } catch (e) {
        // No normal browser window exists; open one without stealing focus.
        await chrome.windows.create({ url: PORTAL_URL, focused: false });
    }
}

// ---------- main check ----------

async function checkAndRecover(reason) {
    if (checking) return;
    checking = true;
    try {
        const status = await detectStatus();
        const { attempts = 0, lastAttemptAt = 0 } =
            await chrome.storage.local.get(["attempts", "lastAttemptAt"]);

        const update = { netStatus: status, lastCheckAt: Date.now() };

        if (status === "online") {
            if (attempts > 0) update.lastLoginAt = Date.now();
            update.attempts = 0;
        } else if (status === "logged_out") {
            const { campusUser, campusPass } =
                await chrome.storage.local.get(["campusUser", "campusPass"]);
            const cooldown = Math.min(BASE_COOLDOWN_MS * 2 ** attempts, MAX_COOLDOWN_MS);

            if (campusUser && campusPass && Date.now() - lastAttemptAt >= cooldown) {
                console.log(`[Auto-Login] Logged out (${reason}); opening portal, attempt ${attempts + 1}`);
                await openPortal();
                update.attempts = attempts + 1;
                update.lastAttemptAt = Date.now();
            }
        }
        // "offline": leave the attempt counter alone and wait for the network.

        await chrome.storage.local.set(update);
    } catch (e) {
        console.warn("[Auto-Login] Status check failed:", e && e.message);
    } finally {
        checking = false;
    }
}

function ensureAlarm() {
    chrome.alarms.get(CHECK_ALARM, (alarm) => {
        if (!alarm) chrome.alarms.create(CHECK_ALARM, { periodInMinutes: CHECK_PERIOD_MIN });
    });
}

// ---------- triggers ----------

chrome.runtime.onInstalled.addListener(() => {
    ensureAlarm();
    checkAndRecover("installed");
});

chrome.runtime.onStartup.addListener(() => {
    ensureAlarm();
    // Browser start: reset backoff so the first check can act right away.
    chrome.storage.local.set({ attempts: 0, lastAttemptAt: 0 });
    checkAndRecover("startup");
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === CHECK_ALARM) checkAndRecover("periodic");
});

// Waking from sleep / unlocking the screen.
chrome.idle.onStateChanged.addListener((state) => {
    if (state === "active") checkAndRecover("wake");
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "check_now") {
        // Manual check from the popup: skip the backoff wait.
        chrome.storage.local.set({ attempts: 0, lastAttemptAt: 0 }, () => {
            checkAndRecover("manual").then(() => sendResponse({ ok: true }));
        });
        return true;
    }
    if (request.action === "open_portal") {
        openPortal().then(() => sendResponse({ ok: true }));
        return true;
    }
});

ensureAlarm();
